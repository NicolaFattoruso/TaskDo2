package com.example.android.taskdo;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

/**
 * Entity: Represents a table within the database.
 */
@Entity(tableName = "tasks")
public class Task {

    @PrimaryKey(autoGenerate = true)
    private Long ID;

    /**
     * Name of the taks
     */
    @ColumnInfo(name = "task_name")
    private String taskName;

    /**
     * Variable to keep of the status of the task [Done or Not Done]
     */
    @ColumnInfo(name = "task_status")
    private Boolean taskStatus;

    public Task(String taskName, Boolean taskStatus) {
        this.taskName = taskName;
        this.taskStatus = taskStatus;
    }



    /**
     * @return the name of the Task
     */
    public String getTaskName() {
        if (taskName != null)
            return taskName;
        else
            return "NULL VALUE";
    }

    /**
     * @return true if task has been done, false if task has not been done yet.
     */
    public Boolean getTaskStatus() {
        return taskStatus;
    }

    public Long getID() {
        return ID;
    }

    public void setID(@NonNull Long ID) {
        this.ID = ID;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public void setTaskStatus(Boolean taskStatus) {
        this.taskStatus = taskStatus;
    }

    public void changeTaskStatus()
    {
        if(taskStatus == false)
            taskStatus = true;
        else
            taskStatus = false;
    }

    @Override
    public String toString() {
        return "Task Name: " + taskName;
    }
}


