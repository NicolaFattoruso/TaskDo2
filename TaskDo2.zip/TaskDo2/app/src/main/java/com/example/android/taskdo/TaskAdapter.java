package com.example.android.taskdo;

import android.app.Activity;
import android.graphics.Paint;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.List;

public class TaskAdapter extends ArrayAdapter<Task> {

    private static final String TAG = "TaskAdapter";


    /**
     * Constructor for the TaskAdapter
     *
     * @param context is the context of the app
     * @param tasks   is the ArrayList of Tasks to be displayed
     */
    public TaskAdapter(Activity context, List<Task> tasks) {
        super(context, 0, tasks);
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View listItemView = convertView;

        //If first item is not yet present, inflate it
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.task_item, parent, false);
        }

        //Store the current Task in a task Object named currentTask
        final Task currentTask = getItem(position);

        //Sets the current taskName in the task_name TextView
        TextView taskName = listItemView.findViewById(R.id.task_name);
        taskName.setText(currentTask.getTaskName());
        if (currentTask.getTaskStatus() == true) {
            taskName.setPaintFlags(taskName.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        }
        else{
            taskName.setPaintFlags(taskName.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            taskName.setPaintFlags( taskName.getPaintFlags() & (~ Paint.STRIKE_THRU_TEXT_FLAG));
        }


        return listItemView;

    }
}
