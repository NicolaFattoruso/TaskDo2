package com.example.android.taskdo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    List<Task> taskList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Database?!
        final AppDatabase db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "database")
                .allowMainThreadQueries().build();

        taskList = db.TaskDao().getAllTasks();


        /** Create an {@link TaskAdapter}, whose data source is a list of
         {@link Task}s. The adapter knows how to create list item views for each item
         in the list. */
        final TaskAdapter taskAdapter = new TaskAdapter(this, taskList);

        // Get a reference to the ListView, and attach the adapter to the listView.
        ListView listView = findViewById(R.id.list);
        listView.setAdapter(taskAdapter);

        //Find Button for adding a task
        Button addTaskButton = findViewById(R.id.add_task);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Task currentTask = taskList.get(i);
                currentTask.changeTaskStatus();
                db.TaskDao().updateTaskStatus(currentTask.getTaskStatus(), currentTask.getID());
                taskAdapter.notifyDataSetChanged();
            }
        });

        //Sets an onClickListener on the addTaskButton to add a new Task on tap
        addTaskButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addTaskIntent();
                finish();
            }
        });
    }


    /**
     * Function to start another activity to get the name of the Task
     */
    private void addTaskIntent() {
        Intent addTaskIntent = new Intent(this, AddTaskActivity.class);
        startActivity(addTaskIntent);
    }


}

