package com.example.android.taskdo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddTaskActivity extends AppCompatActivity {

    String taskName = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        //Find the the editable text view and save the name of the task into taskName string
        final EditText taskNameEdit = findViewById(R.id.task_name_edit);

        //Find the button to add the Task
        Button addButton = findViewById(R.id.add_button);

        //DATABASE?!
        final AppDatabase db = Room.databaseBuilder(getApplicationContext(),
                AppDatabase.class, "database").allowMainThreadQueries().build();


        //Sets an onClickListener on addButton to add the new task in the list
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                taskName = taskNameEdit.getText().toString();
                if (TextUtils.isEmpty(taskName)) {
                    Toast.makeText(AddTaskActivity.this, "TODO// Please add a name for your task", Toast.LENGTH_SHORT).show();
                } else {
                    db.TaskDao().insertTasks(new Task(taskNameEdit.getText().toString(), false));
                    startActivity(new Intent(AddTaskActivity.this, MainActivity.class));
                    finish();
                }
            }
        });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(AddTaskActivity.this, MainActivity.class));

    }
}
